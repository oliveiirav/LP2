﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[7, 2];
            double[] med = new double[2];
            string auxiliar1 = "";


            for (int pessoa = 0; pessoa < 7; pessoa++)
            {
                for (int filme = 0; filme < 2; filme++)
                {
                    auxiliar1 = Interaction.InputBox($"Digite a nota da {pessoa + 1}a pessoa do {filme + 1}o  filme: ");
                    if (!Double.TryParse(auxiliar1, out matriz[pessoa, filme]))
                    {
                        MessageBox.Show("A nota deve ser de 0 a 10");
                        filme--;
                    }
                    else
                       if (matriz[pessoa, filme] < 0 || matriz[pessoa, filme] > 10)
                    {
                        MessageBox.Show("A nota deve ser de 0 a 10");
                        pessoa--;


                    }

                }
            }
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    med[i] = med[i] + matriz[j, i];
                }
                med[i] = med[i] / 7;
            }
            for (int i = 0; i < 7; i++)
            {
                string aux = $"Pessoa: {i +1}   Nota Filme 1: {matriz[i, 0]}    Nota Filme 2: {matriz[i, 1]}";
                lboxNotas.Items.Add(aux);
            }
            string espaco = $"--------------------------------------------------------------------";
            lboxNotas.Items.Add(espaco);

            for (int j = 0; j < 2; j++)
            {
                string media = $" Média filme {j + 1}:   {med[j]:F2}";
                lboxNotas.Items.Add(media);
            }
        }
    }
}

